# LaTeX VXML Final Report

This directory contains a $\LaTeX$ template for your VXML final report. To use
it, simply edit the content areas and run it through a tool such as `pdflatex`
to produce a PDF version of your report.
